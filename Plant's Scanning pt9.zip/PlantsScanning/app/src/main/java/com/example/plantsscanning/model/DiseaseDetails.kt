package com.example.plantsscanning.model

data class DiseaseDetails(
    val name: String,
    val cause: String,
    val solution: String
)